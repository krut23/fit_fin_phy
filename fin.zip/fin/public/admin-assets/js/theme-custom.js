// File for your custom JavaScript
$(window).on('load', function(){
    $('#preloader').addClass('d-none');
});
