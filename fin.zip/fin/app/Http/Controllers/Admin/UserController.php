<?php

namespace App\Http\Controllers\Admin;

use Validator;
use Illuminate\Http\Request;
use App\Infrastructure\Media;
use App\Models\PhoneBookUser;
use Illuminate\Support\Facades\DB;
use App\Infrastructure\ServiceResponse;
use App\Http\Controllers\BaseController;


class UserController extends BaseController
{
    public $pageTitle = ['s' => 'User', 'p' => 'Users'];

    public function expiredDate()
    {
        $expires_at = now()->subDays(30);
        PhoneBookUser::where('last_login_at','<=',$expires_at)->update(['is_active'=>0]);
        return redirect()->back();
    }

    /**
     * Display a view
     * Method GET
     */
    public function index() {

        $clicksRouts = [];
        foreach (CLICK_KEYS as $key) {
            $clicksRouts[] = ['name' => ucwords(str_replace('-', ' ', $key)), 'url' => route('clicks', $key).'/'];
        }
        $viewData = [
            'pageTitle' => $this->pageTitle,
            'routes' => [
                'show' => route('users.show'),
//                'store' => route('school.store'),
//                'destroy' => route('school.destroy'),
//                'update' => route('school.update'),
            ],
            'breadcrumbs' => [ /*['label' => 'Dashboard', 'route' => route('dashboard')]*/],
            'clicksRouts' => $clicksRouts,
        ];

        return view('admin.common-list', [
            'title' => $this->pageTitle['p'],
            'jsController' => 'userCtrl',
            'viewData' => json_encode($viewData),
        ]);
    }

    /**
     * Get data list.
     * Method POST
     */
    public function show(Request $request)
    {
        $response = new ServiceResponse();
        $reqData = $request->all();
        $pageData = [];
        $query = PhoneBookUser::query();

        // Apply filters [
        $query = $this->applyFilters($query, $reqData['dataTableFields'], $reqData['dataTableCommonSearch']);
        // ] Apply filters


        // Apply execution [
        list($isFound, $records, $reqData, $pageData) = $this->applyExecution($query, $reqData, $pageData);
        // Apply execution [

        if ($isFound) {
            $index = $reqData['startIndex'] + 1;
            foreach ($records as $i => $row) {
                $row['index'] = $index++;
            //  $row['profile_url'] = Media::get($row['profile_url']);
                $records[$i] = $row;
            }
        }

        $pageData['filteredData'] = $records;

        $response->Data = $pageData;
        $response->IsSuccess = true;
        return $this->GetJsonResponse($response);
    }

    // public function active(Request $request)
    // {

    //         // $titleS = '';
    //         // $titleP = '';
    //         // $dataTableFields = [
    //         //     'id' => ['label' => null, 'isSortable' => 0, 'isSearchable' => 0, 'isShowInTable' => 0, 'isShowInTableChecked' => 0, 'displayType' => 'badge', 'inputType' => 'text', 'searchType' => 'like', 'val' => null],
    //         //     'profile_url' => ['label' => 'Image', 'isSortable' => 0, 'isSearchable' => 0, 'isShowInTable' => 1, 'isShowInTableChecked' => 1, 'displayType' => 'profile-image', 'inputType' => 'text', 'val' => null],
    //         //     'name' => ['label' => 'Name', 'isSortable' => 1, 'isSearchable' => 1, 'isShowInTable' => 1, 'isShowInTableChecked' => 1, 'displayType' => 'text', 'inputType' => 'text', 'searchType' => 'like', 'val' => null],
    //         //     'phone' => ['label' => 'Phone', 'isSortable' => 1, 'isSearchable' => 1, 'isShowInTable' => 1, 'isShowInTableChecked' => 1, 'displayType' => 'text', 'inputType' => 'text', 'searchType' => 'like', 'val' => null],
    //         //     'email' => ['label' => 'Email', 'isSortable' => 1, 'isSearchable' => 1, 'isShowInTable' => 1, 'isShowInTableChecked' => 1, 'displayType' => 'text', 'inputType' => 'text', 'searchType' => 'like', 'val' => null],
    //         //     'click' => ['label' => 'Clicks', 'isSortable' => 0, 'isSearchable' => 0, 'isShowInTable' => 1, 'isShowInTableChecked' => 1, 'displayType' => 'clicks-redirect', 'inputType' => 'text', 'searchType' => 'like', 'val' => null],
    //         //     'is_active' => ['label' => 'inactive', 'isSortable' => 1, 'isSearchable' => 1, 'isShowInTable' => 1, 'isShowInTableChecked' => 1, 'displayType' => 'flip-btn-status', 'inputType' => 'check-list', 'searchType' => 'id', 'val' => null, 'select' => []],
    //         // ];

    //         // return view('', compact('titleS', 'titleP', 'dataTableFields'));

    //         $titleS = "In-Active-User";
    //         // $titleP = "Your Title P";

    //         // Retrieve data from the database using the query builder
    //         $data = DB::table('phone_book_users')
    //                     ->select('id', 'profile_url', 'name', 'phone', 'email','is_active')
    //                     ->get();

    //         return view('inactive', compact('titleS', 'data'));

    // }



}
