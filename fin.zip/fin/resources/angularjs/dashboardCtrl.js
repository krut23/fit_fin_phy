app.controller('PageCtrl', function ($scope, $rootScope, $http, $log, form, helperServices) {

    const dd = $rootScope.dataLog;


});


