LuCompanyName
	name


LuSalaryMode
	name


LuEducation
	name


LuProfession
	name


Customer
	first_name
	last_name
	phone
	email
	birth_date

	gender
	marital_status
	employee_type
	lu_company_name_id
	lu_salary_mode_id
	monthly_income
	lu_education_id
	lu_profession_id	

	pin_code
	address_line_1
	address_line_2
	city
	
	pan_card_image
	pan_number
	is_verified_pan_number

	addhar_card_image
	addhar_number
	is_verified_addhar_number

	passport_image

	father_name
	mother_name
	contact_reference
	family_phone
	friend_name
	friend_phone

	referral_code
	total_referral
	referral_by

	is_complete_check_eligibility
	is_complete_kyc
	is_complete_profile_details
	is_complete_reference_details
    is_verified

    token
    otp
    fcm_token
    api_token
	is_active



