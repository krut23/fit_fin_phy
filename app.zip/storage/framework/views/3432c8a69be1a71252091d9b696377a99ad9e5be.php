<?php $__env->startSection('title',!empty($title) ? $title : ''); ?>
<?php $__env->startSection('content'); ?>

    <!-- Form -->
    <?php echo $__env->make('admin.modals.forms.form-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End Form -->

    <div class="content container-fluid" ng-if="formOpenType.type === 'form'">
        <div class="row">
            <div class="col-sm-12 col-xl-6" ng-show="sendedNotification.length">
                <div class="card">
                    <div class="card-header pb-0">
                        <h5>Processing ({{sendedNotification.length}} / {{customers.length}})</h5>
                    </div>
                    <div class="card-body">

                        <ANY ng-repeat="noti in sendedNotification">
                            <div class="alert fade show mb-1" ng-class="{'alert-primary': noti.isSuccess == 1, 'alert-danger': noti.isSuccess == 0, 'alert-dark': noti.isSuccess == -1}" role="alert">
                                <strong>{{noti.id}} - {{noti.message}}&emsp; </strong>{{noti.name}}
                            </div>

                        </ANY>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('resources/angularjs/'.$jsController.'.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layouts/admin-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/prayosh1/public_html/fit-fin-phy/resources/views/admin/common-notification.blade.php ENDPATH**/ ?>