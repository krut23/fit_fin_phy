<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\BaseController;
use App\Infrastructure\ApiServiceResponse;
use App\Models\PhoneBookUser;
use App\Models\User;
use Illuminate\Http\Request;
use Validator, Hash;

class AuthController extends BaseController
{

    // Login
    public function login(Request $request) {

        $response = new ApiServiceResponse();
        $reqData = $request->all();

        // check validation [
        $validator = Validator::make($reqData, [
            'email' => 'required',
        ]);

        if ($validator->fails()) return $this->sendFail($this->getValidationMessagesFormat($validator->messages()));
        // ] Check validation


        $record = PhoneBookUser::where(['email' => $reqData['email']])->first();
//        dd($record);
        if (empty($record)) {
            $record = new PhoneBookUser;
            $record->name = getValue($reqData, 'name');
            $record->email = getValue($reqData, 'email');
            $record->phone = getValue($reqData, 'phone');
            $record->profile_url = getValue($reqData, 'profile_url');
            $record->social_id = getValue($reqData, 'social_id');
        }

        $apiToken = $response->getNewApiToken($record->id);
        $record->api_token = $apiToken;
        $record->fcm_token = getValue($reqData, 'fcm_token');
        $record->save();

        $record = PhoneBookUser::where(['email' => $reqData['email']])->first()->toArray();
        $record['api_token'] = $apiToken;

        return $this->sendSuccess($record, 'Login Successfully');


    }

    // Logout
    public function logout(Request $request) {

        $response = new ApiServiceResponse();
        $reqData = $request->all();

//        $user = User::find(_user->id);
//        $user->api_token = null;
//        $user->save();

        return $this->sendSuccess(null, 'Logout Successfully');


    }


}
